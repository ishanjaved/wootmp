<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package _s
 */

?>

  <!-- START FOOTER AREA -->
        <footer id="footer" class="footer-area">
          
<?php if(!(is_home() || is_single() || is_cart() || is_checkout())){ ?>
		  <div class="footer-top">
                <div class="container-fluid">
                    <div class="plr-185">
                        <div class="footer-top-inner gray-bg">
                            <div class="row">
                                <div class="col-lg-4 col-md-5 col-sm-4">
                                    <div class="single-footer footer-about">
                                        <div class="footer-logo">
                                            
                                        </div>
                                        <div class="footer-brief">
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the subas industry's standard dummy text ever since the 1500s,</p>
                                            <p>When an unknown printer took a galley of type and If you are going to use a passage of Lorem Ipsum scrambled it to make.</p>
											<p><?php //echo get_option('twitterid') ?></p>
                                        </div>
                                        <ul class="footer-social">
                                            <li>
                                                <a class="facebook" href="" title="Facebook"><i class="zmdi zmdi-facebook"></i></a>
                                            </li>
                                            <li>
                                                <a class="google-plus" href="" title="Google Plus"><i class="zmdi zmdi-google-plus"></i></a>
                                            </li>
                                            <li>
                                                <a class="twitter" href="" title="Twitter"><i class="zmdi zmdi-twitter"></i></a>
                                            </li>
                                            <li>
                                                <a class="rss" href="" title="RSS"><i class="zmdi zmdi-rss"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-2 hidden-md hidden-sm">
                                    <div class="single-footer">
                                        <h4 class="footer-title border-left">Categories</h4>
                                        <ul class="footer-menu">
										                     <!-- single-brand-product start -->
		<?php

$taxonomyName = "product_cat";
$prod_categories = get_terms($taxonomyName, array(
    'orderby'=> 'name',
    'order' => 'ASC',
    'hide_empty' => 1
));  

foreach( $prod_categories as $prod_cat ) :
 
    $term_link = get_term_link( $prod_cat, 'product_cat' ); ?>
	
											<li>
                                                <a href="<?php echo $term_link; ?>""><i class="zmdi zmdi-circle"></i><span><?php echo $prod_cat->name; ?></span></a>
                                            </li>
	
             <?php endforeach;  wp_reset_query(); ?>    
                                        
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-md-3 col-sm-4">
                                    <div class="single-footer">
                                        <h4 class="footer-title border-left">my account</h4>
                                        <ul class="footer-menu">
                                            <li>
                                                <a href="<?php $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' ); if ( $myaccount_page_id ) { echo $myaccount_page_url = get_permalink( $myaccount_page_id ); }?>"><i class="zmdi zmdi-circle"></i><span>My Account</span></a>
                                            </li>
                                            <li>
                                                <a href="<?php  global $woocommerce; $cart_url = $woocommerce->cart->get_cart_url(); echo $cart_url; ?>"><i class="zmdi zmdi-circle"></i><span>My Cart</span></a>
                                            </li>
                                            <li>
                                                <a href="<?php echo wp_login_url( get_permalink() ); ?>"><i class="zmdi zmdi-circle"></i><span>Sign In</span></a>
                                            </li>
                                            <li>
                                                <a href="<?php $myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' ); if ( $myaccount_page_id ) { echo $myaccount_page_url = get_permalink( $myaccount_page_id ); }?>"><i class="zmdi zmdi-circle"></i><span>Registration</span></a>
                                            </li>
                                            <li>
                                                <a href="<?php  global $woocommerce; $checkout_url = $woocommerce->cart->get_checkout_url(); echo $checkout_url; ?>"><i class="zmdi zmdi-circle"></i><span>Check out</span></a>
                                            </li>
                                            <li>
                                                <a href="order.html"><i class="zmdi zmdi-circle"></i><span>Order Complete</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-md-4 col-sm-4">
                                    <div class="single-footer">
                                        <h4 class="footer-title border-left">Get in touch</h4>
                                        <div class="footer-message">
                                           
                                                <input type="text" name="name" class="input-name" placeholder="Your name here...">
                                                <input type="text" name="email" class="input-email" placeholder="Your email here...">
                                                <textarea class="height-80 input-message"  name="message" placeholder="Your messege here..."></textarea>
                                                <button class="submit-btn-1 mt-20 btn-hover-1 submit" >submit message</button> 
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<?php  } ?>
            <div class="footer-bottom black-bg">
                <div class="container-fluid">
                    <div class="plr-185">
                        <div class="copyright">
                            <div class="row">
                                <div class="col-sm-6 col-xs-12">
                                    <div class="copyright-text">
                                        <p>&copy; <a href="" target="_blank">Ishan  </a> 2016. All Rights Reserved.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-xs-12">
                                    <ul class="footer-payment text-right">
                                       
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- END FOOTER AREA -->
<?php wp_footer(); ?>

</body>
</html>
<script>

	
		jQuery('.menu-all-pages-container > ul').dropotron({ 
// OPTIONS HERE
});
	

</script>

    <script>
    	 jQuery(document).ready(function() {
            jQuery('.woocommerce-product-gallery__wrapper').lightSlider({
                gallery:true,
                item:1,
                thumbItem:9,
                slideMargin: 0,
                speed:500,
                auto:true,
                loop:true,
                onSliderLoad: function() {
                    jQuery('.woocommerce-product-gallery__wrapper').removeClass('cS-hidden');
                }  
            });
		});
    </script>
	
	<script>
	
 jQuery(document).ready(function() {
 
});
	
	</script>