<?php 

/* Template Name: front-page */


get_header(); ?>

	   <!-- START SLIDER AREA -->
     	    <div class="slider-area  plr-185  mb-80">
            <div class="container-fluid">
                <div class="slider-content">
                    <div class="row">
                        <div class="active-slider-1 slick-arrow-1 slick-dots-1">
                            <!-- layer-1 Start -->
                         <?php 
				$loop = new WP_Query(array('post_type' => 'slider', 'posts_per_page' => -1, 'orderby'=> 'ASC')); 
			?>
			<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>                           
						   <div class="col-md-12">
                                <div class="layer-1">
                                    <div class="slider-img">
                                        <?php $url = get_post_meta($post->ID, "url", true);
					if($url!='') { 
						echo '<a href="'.$url.'">';
						echo the_post_thumbnail('full');
						echo '</a>';
					} else {
						echo the_post_thumbnail('full');
					} ?>
                                    </div>
                                   
                                </div>
                            </div>
			<?php endwhile; ?>
			
			<?php wp_reset_query(); ?>

		</div>
	</div>
	</div>
	</div>
	</div>		
        <!-- END SLIDER AREA -->
    
	<!-- Start page content -->
        <section id="page-content" class="page-wrapper">
        <div class="by-brand-section mb-80">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="section-title text-left mb-40">
                                <h2 class="uppercase">Categories</h2>
                                <h6>There are many Catogries available,</h6>
                            </div>
                        </div>
                    </div>
					
					<div class="by-brand-product">
                        <div class="row active-by-brand slick-arrow-2">
                            <!-- single-brand-product start -->
		<?php

$taxonomyName = "product_cat";
$prod_categories = get_terms($taxonomyName, array(
    'orderby'=> 'name',
    'order' => 'ASC',
    'hide_empty' => 1
));  

foreach( $prod_categories as $prod_cat ) :
 
    $cat_thumb_id = get_woocommerce_term_meta( $prod_cat->term_id, 'thumbnail_id', true );
    $cat_thumb_url = wp_get_attachment_image_src( $cat_thumb_id, 'thumbnail-size' )[0]; // Change to desired 'thumbnail-size'
    $term_link = get_term_link( $prod_cat, 'product_cat' ); ?>
	
	<div class="col-xs-12">
                                <div class="single-brand-product">
                                    <a href="<?php echo $term_link; ?>"><img src="<?php echo $cat_thumb_url; ?>" alt=""></a>
                                    <h3 class="brand-title text-gray">
                                        <a href="<?php echo $term_link; ?>"><?php echo $prod_cat->name; ?></a>
                                    </h3>
                                </div>
                            </div>
	
    <?php endforeach; 
wp_reset_query(); ?>                          
							</div></div>
		</div></div>

		 <div class="featured-product-section mb-50">
                <div class="container">
		        <div class="row">
                        <div class="col-md-12">
                            <div class="section-title text-left mb-40">
                                <h2 class="uppercase">Featured product</h2>
                                <h6>There are many variations of passages of brands available,</h6>
                            </div>
                        </div>
                    </div>
					
					<div class="featured-product">
                        <div class="row active-featured-product slick-arrow-2">
						
						
						
					
	<?php
	$meta_query  = WC()->query->get_meta_query();
		$tax_query   = WC()->query->get_tax_query();
		$tax_query[] = array(
			'taxonomy' => 'product_visibility',
			'field'    => 'name',
			'terms'    => 'featured',
			'operator' => 'IN',
		);
	
 $args = array(
    'post_type'   =>  'product',
    'stock'       =>  1,
    'showposts'   =>  6,
    'orderby'     =>  'date',
    'order'       =>  'DESC',
    'meta_query'  =>  $meta_query,
	'tax_query'   => $tax_query,
);
     $loop = new WP_Query( $args );
     while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
                        

						 <div class="col-xs-12">
                                <div class="product-item">
                                    <div class="product-img">
                                         <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
                                            <?php //woocommerce_show_product_sale_flash( $post, $product ); ?>
                                <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?></a>
                                    </div>
                                    <div class="product-info">
                                        <h6 class="product-title">
                                            <a href="<?php echo get_permalink( $loop->post->ID ) ?>"><?php the_title(); ?></a>
                                        </h6>
                                        <div class="pro-rating woocommerce">
										<?php //echo wc_get_rating_html( $product->get_average_rating($loop->post->ID ) ); 
								//echo woocommerce_template_loop_rating(); ?>
<?php                                  
$rating_count = $product->get_rating_count($loop->post->ID);
$average      = $product->get_average_rating($loop->post->ID);

if ( $average > 0 ) { ?>

		<div class="star-rating">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<?php
				/* translators: 1: average rating 2: max rating (i.e. 5) */
				printf(
					__( '%1$s out of %2$s', 'woocommerce' ),
					'<strong class="rating">' . esc_html( $average ) . '</strong>',
					'<span>5</span>'
				);
				?>
				<?php
				/* translators: %s: rating count */
				printf(
					_n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ),
					'<span class="rating">' . esc_html( $rating_count ) . '</span>'
				);
				?>
			</span>

		
	</div>

<?php }else{ echo 'Not rated';} ?>


								  </div>
                                        <h3 class="pro-price"><?php echo $product->get_price_html(); ?></h3>
                                        <ul class="action-button">
                                            <li>
                                                <a href="<?php echo '?add-to-cart='.$loop->post->ID; ?>" title="Add to cart"><i class="zmdi zmdi-shopping-cart"></i>&nbsp;Add to cart</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
						
                <?php
            /**
             * woocommerce_pagination hook
             *
             * @hooked woocommerce_pagination - 10
             * @hooked woocommerce_catalog_ordering - 20
             */
        ?>
<?php endwhile; ?>
<?php wp_reset_query(); ?>
		
		</div></div>
		</div></div>
		
		  <!-- PRODUCT TAB SECTION START -->
            <div class="product-tab-section mb-50">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-12 col-xs-12">
                            <div class="section-title text-left mb-40">
                                <h2 class="uppercase">product list</h2>
                                <h6>There are many variations of passages of brands available,</h6>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-12 col-xs-12">
                            <div class="pro-tab-menu text-right">
                                <!-- Nav tabs -->
                                <ul class="tabbs" >
                                    <li class="active"><a href="#popular-product" data-toggle="tab">Popular Products </a></li>
                                    <li><a href="#new-arrival" data-toggle="tab">New Arrival</a></li>
                                    <li><a href="#special-offer"  data-toggle="tab">Special Offer</a></li>
                                </ul>
                            </div>                       
                        </div>
                    </div>
                    <div class="product-tab">
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <!-- popular-product start -->
                            <div class="tab-pane active fade in" id="popular-product">
                                <div class="row">
                                
								<?php
$posts_per_page = 8;

$meta_query = WC()->query->get_meta_query();

$atts = array(
	'orderby' => 'title',
	'order'   => 'asc');
	
$args = array(
	'post_type'           => 'product',
	'post_status'         => 'publish',
	'ignore_sticky_posts' => 1,
	'posts_per_page'      => $posts_per_page,
	'meta_key'            => 'total_sales',
	'orderby'             => 'meta_value_num',
	'meta_query'          => $meta_query
);		

$loop = new WP_Query(apply_filters('woocommerce_shortcode_products_query', $args, $atts));
     while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
                        

						  <div class="col-md-3 hidden-sm col-xs-12">
                                <div class="product-item">
                                    <div class="product-img">
                                         <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
                                            <?php //woocommerce_show_product_sale_flash( $post, $product ); ?>
                                <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?></a>
                                    </div>
                                    <div class="product-info">
                                        <h6 class="product-title">
                                            <a href="<?php echo get_permalink( $loop->post->ID ) ?>"><?php the_title(); ?></a>
                                        </h6>
                                        <div class="pro-rating woocommerce">
										<?php //echo wc_get_rating_html( $product->get_average_rating($loop->post->ID ) ); 
								//echo woocommerce_template_loop_rating(); ?>
<?php                                  
$rating_count = $product->get_rating_count($loop->post->ID);
$average      = $product->get_average_rating($loop->post->ID);

if ( $average > 0 ) { ?>

		<div class="star-rating">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<?php
				/* translators: 1: average rating 2: max rating (i.e. 5) */
				printf(
					__( '%1$s out of %2$s', 'woocommerce' ),
					'<strong class="rating">' . esc_html( $average ) . '</strong>',
					'<span>5</span>'
				);
				?>
				<?php
				/* translators: %s: rating count */
				printf(
					_n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ),
					'<span class="rating">' . esc_html( $rating_count ) . '</span>'
				);
				?>
			</span>

		
	</div>

<?php }else{ echo 'Not rated';} ?>


								  </div>
                                        <h3 class="pro-price"><?php echo $product->get_price_html(); ?></h3>
                                        <ul class="action-button">
                                            <li>
                                                <a href="<?php echo '?add-to-cart='.$loop->post->ID; ?>" title="Add to cart"><i class="zmdi zmdi-shopping-cart"></i>&nbsp;Add to cart</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
						
                <?php
            /**
             * woocommerce_pagination hook
             *
             * @hooked woocommerce_pagination - 10
             * @hooked woocommerce_catalog_ordering - 20
             */
        ?>
<?php endwhile; ?>
<?php wp_reset_query(); ?>
                                    <!-- product-item start -->
                                    
                                    <!-- product-item end -->
                                </div>
                            </div>
                            <!-- popular-product end -->
                            <!-- new-arrival start -->
                            <div class="tab-pane fade" id="new-arrival">
                                <div class="row">

								
								 
								<?php
$args = array( 'post_type' => 'product', 'stock' => 1, 'posts_per_page' => 8, 'orderby' =>'date','order' => 'DESC' );
            $loop = new WP_Query( $args );

     while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
                        

						  <div class="col-md-3 hidden-sm col-xs-12">
                                <div class="product-item">
                                    <div class="product-img">
                                         <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
                                            <?php //woocommerce_show_product_sale_flash( $post, $product ); ?>
                                <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?></a>
                                    </div>
                                    <div class="product-info">
                                        <h6 class="product-title">
                                            <a href="<?php echo get_permalink( $loop->post->ID ) ?>"><?php the_title(); ?></a>
                                        </h6>
                                       <div class="pro-rating woocommerce">
										<?php //echo wc_get_rating_html( $product->get_average_rating($loop->post->ID ) ); 
								//echo woocommerce_template_loop_rating(); ?>
<?php                                  
$rating_count = $product->get_rating_count($loop->post->ID);
$average      = $product->get_average_rating($loop->post->ID);

if ( $average > 0 ) { ?>

		<div class="star-rating">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<?php
				/* translators: 1: average rating 2: max rating (i.e. 5) */
				printf(
					__( '%1$s out of %2$s', 'woocommerce' ),
					'<strong class="rating">' . esc_html( $average ) . '</strong>',
					'<span>5</span>'
				);
				?>
				<?php
				/* translators: %s: rating count */
				printf(
					_n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ),
					'<span class="rating">' . esc_html( $rating_count ) . '</span>'
				);
				?>
			</span>

		
	</div>

<?php }else{ echo 'Not rated';} ?>


								  </div>
                                        <h3 class="pro-price"><?php echo $product->get_price_html(); ?></h3>
                                        <ul class="action-button">
                                            <li>
                                                <a href="<?php echo '?add-to-cart='.$loop->post->ID; ?>" title="Add to cart"><i class="zmdi zmdi-shopping-cart"></i>&nbsp;Add to cart</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
						
                <?php
            /**
             * woocommerce_pagination hook
             *
             * @hooked woocommerce_pagination - 10
             * @hooked woocommerce_catalog_ordering - 20
             */
        ?>
<?php endwhile; ?>
<?php wp_reset_query(); ?>
								

								</div></div>
                            <!-- new-arrival end -->
                            
                            <!-- special-offer start -->
                            <div class="tab-pane fade" id="special-offer">
                                <div class="row">
								
											<?php
$args = array(
    'post_type'      => 'product',
    'posts_per_page' => 8,
    'meta_query'     => array(
        'relation' => 'OR',
        array( // Simple products type
            'key'           => '_sale_price',
            'value'         => 0,
            'compare'       => '>',
            'type'          => 'numeric'
        ),
        array( // Variable products type
            'key'           => '_min_variation_sale_price',
            'value'         => 0,
            'compare'       => '>',
            'type'          => 'numeric'
        )
    )
);

            $loop = new WP_Query( $args );

     while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>
                        

						  <div class="col-md-3 hidden-sm col-xs-12">
                                <div class="product-item">
                                    <div class="product-img">
                                         <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
                                            <?php //woocommerce_show_product_sale_flash( $post, $product ); ?>
                                <?php if (has_post_thumbnail( $loop->post->ID )) echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="Placeholder" width="300px" height="300px" />'; ?></a>
                                    </div>
                                    <div class="product-info">
                                        <h6 class="product-title">
                                            <a href="<?php echo get_permalink( $loop->post->ID ) ?>"><?php the_title(); ?></a>
                                        </h6>
                                       <div class="pro-rating woocommerce">
										<?php //echo wc_get_rating_html( $product->get_average_rating($loop->post->ID ) ); 
								//echo woocommerce_template_loop_rating(); ?>
<?php                                  
$rating_count = $product->get_rating_count($loop->post->ID);
$average      = $product->get_average_rating($loop->post->ID);

if ( $average > 0 ) { ?>

		<div class="star-rating">
			<span style="width:<?php echo ( ( $average / 5 ) * 100 ); ?>%">
				<?php
				/* translators: 1: average rating 2: max rating (i.e. 5) */
				printf(
					__( '%1$s out of %2$s', 'woocommerce' ),
					'<strong class="rating">' . esc_html( $average ) . '</strong>',
					'<span>5</span>'
				);
				?>
				<?php
				/* translators: %s: rating count */
				printf(
					_n( 'based on %s customer rating', 'based on %s customer ratings', $rating_count, 'woocommerce' ),
					'<span class="rating">' . esc_html( $rating_count ) . '</span>'
				);
				?>
			</span>

		
	</div>

<?php }else{ echo 'Not rated';} ?>


								  </div>
                                        <h3 class="pro-price"><?php echo $product->get_price_html(); ?></h3>
                                        <ul class="action-button">
                                            <li>
                                                <a href="<?php echo '?add-to-cart='.$loop->post->ID; ?>" title="Add to cart"><i class="zmdi zmdi-shopping-cart"></i>&nbsp;Add to cart</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
						
                <?php
            /**
             * woocommerce_pagination hook
             *
             * @hooked woocommerce_pagination - 10
             * @hooked woocommerce_catalog_ordering - 20
             */
        ?>
<?php endwhile; ?>
<?php wp_reset_query(); ?>
								
								</div></div>
                            <!-- special-offer end -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- PRODUCT TAB SECTION END -->
		
	</section>
        <!-- End page content -->



















<?php  get_footer();  ?>