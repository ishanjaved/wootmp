<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package _s
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div class="wrapper">

	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', '_s' ); ?></a>

	<!-- START HEADER AREA -->
        <header class="header-area header-wrapper">
            <!-- header-top-bar -->
            <div class="header-top-bar plr-185">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6 hidden-xs">
                            <div class="call-us">
                                <p class="mb-0 roboto">(+88) 01234-567890</p>
                            </div>
                        </div>
                        <div class="col-sm-6 col-xs-12">
                            <div class="top-link clearfix">
                                <ul class="link f-right">
                                    <li>
                                       
                                         <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>" title="<?php _e('My Account',''); ?>"><i class="zmdi zmdi-account"></i>
                                            My Account </a>
                                        
                                    </li>
                                    <?php  
                                     if ( !is_user_logged_in() ) {
										?>
									<li>
									
										<a href="<?php echo wp_login_url( get_permalink() ); ?>" title="Login">
                                            <i class="zmdi zmdi-lock"></i>
                                           Login</a>
									    
                                    </li> <?php }else{ ?>
										
										<li>
										<a href="<?php echo wp_logout_url( home_url() ); ?>"><i class="zmdi zmdi-lock-open"></i>Logout</a>
								
								        </li>
								<?php	} ?>
                                     
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-middle-area -->
            <div id="sticky-header" class="header-middle-area plr-185">
                <div class="container-fluid">
                    <div class="full-width-mega-dropdown">
                        <div class="row">
                            <!-- logo -->
                            <div class="col-md-2 col-sm-6 col-xs-12">
                                <div class="logo">
                               <?php    if ( function_exists( 'the_custom_logo' ) ) {
                                    the_custom_logo(); } ?>
                                </div>
                            </div>
                            <!-- primary-menu -->
                            <div class="col-md-8 hidden-sm hidden-xs">
                                <nav id="primary-menu main-nav">
                                    
									<?php wp_nav_menu( array( 'menu_class'=>'main-menu text-center','theme_location' => 'menu-1','depth'=>'3' ) ); ?>
									</nav>
                            </div>
                            <!-- header-search & total-cart -->
                            <div class="col-md-2 col-sm-6 col-xs-12">
                                <div class="search-top-cart  f-right">
                                    <!-- header-search -->
                                    <div class="header-search f-left">
                                        <div class="header-search-inner">
                                           <button class="search-toggle">
                                            <i class="zmdi zmdi-search"></i>
                                           </button>
                                            <form role="search" method="get" class="woocommerce-product-search" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                                                <div class="top-search-box">
                                                    <input type="search" class="search-field" placeholder="<?php echo esc_attr_x( 'Search Products&hellip;', 'placeholder', 'woocommerce' ); ?>" value="<?php echo get_search_query(); ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'woocommerce' ); ?>" />

                                                    <button type="submit">
                                                        <i class="zmdi zmdi-search"></i>
                                                    </button>
                                                </div>
                                            </form> 
                                        </div>
                                    </div>
                                    <!-- total-cart -->
                                    <div class="total-cart f-left">
                                        <div class="total-cart-in">
                                            <div class="cart-toggler">
                                                <a href="#">
                                                    <span class="cart-quantity"><?php echo  WC()->cart->get_cart_contents_count(); ?></span><br>
                                                    <span class="cart-icon">
                                                        <i class="zmdi zmdi-shopping-cart"></i>
                                                    </span>
                                                </a>                            
                                            </div>
                                            <ul>
											  <li>
                                                    <div class="top-cart-inner your-cart">
                                                        <h5 class="text-capitalize">Your Cart</h5>
                                                    </div>
                                                </li>
											<?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) :
					$_product = $cart_item['data'];
					// Only display if allowed
					if ( ! apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) || ! $_product->exists() || $cart_item['quantity'] == 0 ) continue;
					// Get price
					$product_price = get_option( 'woocommerce_tax_display_cart' ) == 'excl' ? $_product->get_price_excluding_tax() : $_product->get_price_including_tax();
					$product_price = apply_filters( 'woocommerce_cart_item_price_html', woocommerce_price( $product_price ), $cart_item, $cart_item_key );
					?>
                                              
                                                <li>
                                                    <div class="total-cart-pro">
                                                        <!-- single-cart -->
                                                        <div class="single-cart clearfix">
                                                            <div class="cart-img f-left">
                                                                <a href="<?php echo get_permalink( $cart_item['product_id'] ); ?>">
                                                                    <?php echo $_product->get_image(); ?>
                                                                </a>
                                                                <div class="del-icon">
																<?php echo apply_filters( 
        'woocommerce_cart_item_remove_link', 
        sprintf( 
            '<a href="%s">
              <i class="zmdi zmdi-close"></i>
                   </a>', 
            esc_url( WC()->cart->get_remove_url( $cart_item_key ) ), 
            __( 'Remove this item', 'woocommerce' ) 
        ), 
        $cart_item_key 
    ); ?>
                                                                    
                                                                </div>
                                                            </div>
                                                            <div class="cart-info f-left">
                                                                <h6 class="text-capitalize">
                                                                    <a href="<?php echo get_permalink( $cart_item['product_id'] ); ?>"><?php echo apply_filters('woocommerce_widget_cart_product_title', $_product->get_title(), $_product ); ?></a>
                                                                </h6>
                                                                <p>
                                                                    <span>Price : </span><?php echo apply_filters( 'woocommerce_widget_cart_item_price', '<span class="woffice-mini-cart-price">' . ':' . $product_price . '</span>', $cart_item, $cart_item_key ); ?>
                                                                </p>
                                                                <p>
                                                                    <span>Quantity : </span><?php echo apply_filters( 'woocommerce_widget_cart_item_quantity', '<span class="YOURTHEME-mini-cart-quantity">' . ':' . $cart_item['quantity'] . '</span>', $cart_item, $cart_item_key ); ?>
                                                                </p>
                                                               
                                                            </div>
                                                        </div>
                                                       
                                                </li>
												<?php endforeach; ?>
                                                <li>
                                                    <div class="top-cart-inner subtotal">
                                                        <h4 class="text-uppercase g-font-2">
                                                            Total  =  
                                                            <span><?php echo WC()->cart->get_cart_total(); ?></span>
                                                        </h4>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="top-cart-inner view-cart">
                                                        <h4 class="text-uppercase">
                                                            <a href="<?php echo WC()->cart->get_cart_url();  ?>">View cart</a>
                                                        </h4>
                                                    </div>
                                                </li>
                                                <li>
                                                    <div class="top-cart-inner check-out">
                                                        <h4 class="text-uppercase">
                                                            <a href="<?php echo WC()->cart->get_checkout_url();  ?>">Check out</a>
                                                        </h4>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
		<nav id="site-navigation" class="main-navigation" role="navigation">
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', '_s' ); ?></button>
			
		</nav><!-- #site-navigation -->
        </header>
     	</nav><!-- #site-navigation -->
	</header><!-- #masthead -->

	<div id="content" class="site-content">
