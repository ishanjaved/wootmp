<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package _s
 */

?>

<div class="row">
	<div class="col-md-9 col-sm-9 col-xs-12 single-content">
	<header class="page-header">
		<h1 class="page-title"><?php the_title(); ?></h1>

	</header><!-- .page-header -->

<div class="the-content">
	<?php  the_content(); ?>
</div>
	
<!-- .no-results -->
