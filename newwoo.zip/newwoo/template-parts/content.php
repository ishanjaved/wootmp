<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package _s
 */

?>

<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package _s
 */

?>


<div class="col-md-4 col-sm-6 col-xs-12" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="blog-item">
<?php the_post_thumbnail();?>
<div class="blog-desc">
                                    <h5 class="blog-title"><a href="<?php the_permalink();  ?>"><?php the_title(); ?></a></h5>
                                    <p><?php
			the_excerpt();

			wp_link_pages( array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', '_s' ),
				'after'  => '</div>',
			) );
		?></p>
                                    <div class="read-more">
                                        <a href="<?php the_permalink();  ?>">Read more</a>
                                    </div>
                                    <ul class="blog-meta">
                                        <li>
                                            <a href="#"><i class="zmdi zmdi-comments"></i><?php comments_number( 'no Comments', '1 Comment', '% Comments' ); ?>.</a>
                                        </li>
                                        
                                    </ul>
                                </div>

</div>
	
</div><!-- #post-## -->

